#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

#include "../include/system_call_demo.h"

void system_call_demo()
{
    int fd;
    char buffer[256];

    printf("\n===============================================\n");
    printf("              SYSTEM CALL DEMO\n");
    printf("===============================================\n");

    printf("\nCurrent Process ID using getpid(): %d\n",
           getpid());

    printf("\nOpening /proc/uptime using open()...\n");

    fd = open("/proc/uptime", O_RDONLY);

    if (fd == -1)
    {
        perror("open");
        return;
    }

    printf("File opened successfully.\n");

    int bytes_read = read(fd, buffer, sizeof(buffer) - 1);

    if (bytes_read == -1)
    {
        perror("read");
        close(fd);
        return;
    }

    buffer[bytes_read] = '\0';

    printf("\nData read from /proc/uptime:\n");
    printf("%s", buffer);

    if (close(fd) == -1)
    {
        perror("close");
        return;
    }

    printf("\nSystem calls demonstrated:\n");
    printf("1. getpid()\n");
    printf("2. open()\n");
    printf("3. read()\n");
    printf("4. close()\n");

    printf("\nThese system calls access Linux kernel resources.\n");
}
