#include <stdio.h>
#include <dirent.h>
#include <ctype.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>

#include "../include/event_monitor.h"

#define MAX_PROCESSES 32768

static volatile sig_atomic_t stop_event_monitor = 0;

static void event_signal_handler(int sig)
{
    if (sig == SIGINT)
        stop_event_monitor = 1;
}

static int get_process_snapshot(int pids[])
{
    DIR *dir;
    struct dirent *entry;
    int count = 0;

    dir = opendir("/proc");

    if (dir == NULL)
    {
        perror("opendir");
        return 0;
    }

    while ((entry = readdir(dir)) != NULL)
    {
        if (isdigit((unsigned char)entry->d_name[0]))
        {
            if (count < MAX_PROCESSES)
            {
                int pid = atoi(entry->d_name);

                if (pid > 0)
                {
                    pids[count] = pid;
                    count++;
                }
            }
        }
    }

    closedir(dir);

    return count;
}

static int pid_exists(int pid, int pids[], int count)
{
    for (int i = 0; i < count; i++)
    {
        if (pids[i] == pid)
            return 1;
    }

    return 0;
}

static void get_timestamp(char buffer[], size_t size)
{
    time_t now = time(NULL);
    struct tm *time_info = localtime(&now);

    if (time_info != NULL)
    {
        strftime(buffer, size,
                 "%Y-%m-%d %H:%M:%S",
                 time_info);
    }
}

static void log_event(FILE *log, const char *event, int pid)
{
    char timestamp[64];

    get_timestamp(timestamp, sizeof(timestamp));

    fprintf(log,
            "[%s] [%s] PID: %d\n",
            timestamp,
            event,
            pid);

    fflush(log);
}

static void monitor_process_events(int enable_logging)
{
    int previous_pids[MAX_PROCESSES];
    int current_pids[MAX_PROCESSES];

    int previous_count;
    int current_count;

    FILE *log = NULL;

    stop_event_monitor = 0;

    previous_count =
        get_process_snapshot(previous_pids);

    if (enable_logging)
    {
        log = fopen("logs/events.log", "a");

        if (log == NULL)
        {
            perror("logs/events.log");
            return;
        }

        fprintf(log,
                "\n========== MONITORING SESSION ==========\n");

        fflush(log);
    }

    signal(SIGINT, event_signal_handler);

    printf("\n===============================================\n");

    if (enable_logging)
        printf("              EVENT LOGGING\n");
    else
        printf("       PROCESS CREATION & TERMINATION\n");

    printf("===============================================\n");
    printf("Checking every 2 seconds...\n");
    printf("Press Ctrl+C to return to the main menu.\n\n");

    while (!stop_event_monitor)
    {
        sleep(2);

        current_count =
            get_process_snapshot(current_pids);

        /* Check for created processes */
        for (int i = 0; i < current_count; i++)
        {
            if (!pid_exists(current_pids[i],
                            previous_pids,
                            previous_count))
            {
                char timestamp[64];

                get_timestamp(timestamp, sizeof(timestamp));

                printf("[%s] [CREATED] PID: %d\n",
                       timestamp,
                       current_pids[i]);

                if (log != NULL)
                {
                    log_event(log,
                              "CREATED",
                              current_pids[i]);
                }
            }
        }

        /* Check for terminated processes */
        for (int i = 0; i < previous_count; i++)
        {
            if (!pid_exists(previous_pids[i],
                            current_pids,
                            current_count))
            {
                char timestamp[64];

                get_timestamp(timestamp, sizeof(timestamp));

                printf("[%s] [TERMINATED] PID: %d\n",
                       timestamp,
                       previous_pids[i]);

                if (log != NULL)
                {
                    log_event(log,
                              "TERMINATED",
                              previous_pids[i]);
                }
            }
        }

        /* Save current snapshot */
        for (int i = 0; i < current_count; i++)
        {
            previous_pids[i] = current_pids[i];
        }

        previous_count = current_count;

        fflush(stdout);
    }

    signal(SIGINT, SIG_DFL);

    if (log != NULL)
    {
        fprintf(log,
                "========== MONITORING SESSION ENDED ==========\n");

        fclose(log);
    }

    printf("\nMonitoring stopped.\n");
    printf("Returning to main menu...\n");
}

void process_event_monitor()
{
    monitor_process_events(0);
}

void event_monitor()
{
    monitor_process_events(1);
}
