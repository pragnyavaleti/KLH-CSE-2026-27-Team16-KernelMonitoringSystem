#include <stdio.h>
#include <string.h>
#include "../include/resource_monitor.h"

void cpu_monitor()
{
    FILE *fp = fopen("/proc/loadavg", "r");

    if (fp == NULL)
    {
        perror("fopen");
        return;
    }

    double load1, load5, load15;
    int running, total;

    fscanf(fp, "%lf %lf %lf %d/%d",
           &load1, &load5, &load15,
           &running, &total);

    fclose(fp);

    printf("\n========== CPU MONITORING ==========\n");
    printf("Load Average (1 min)  : %.2f\n", load1);
    printf("Load Average (5 min)  : %.2f\n", load5);
    printf("Load Average (15 min) : %.2f\n", load15);
    printf("Running Processes     : %d\n", running);
    printf("Total Processes       : %d\n", total);
}

void memory_monitor()
{
    FILE *fp = fopen("/proc/meminfo", "r");

    if (fp == NULL)
    {
        perror("fopen");
        return;
    }

    char line[256];
    long mem_total = 0;
    long mem_available = 0;

    while (fgets(line, sizeof(line), fp))
    {
        if (sscanf(line, "MemTotal: %ld kB", &mem_total) == 1)
            continue;

        if (sscanf(line, "MemAvailable: %ld kB", &mem_available) == 1)
            continue;
    }

    fclose(fp);

    printf("\n========== MEMORY MONITORING ==========\n");
    printf("Total Memory     : %ld MB\n", mem_total / 1024);
    printf("Available Memory : %ld MB\n", mem_available / 1024);
    printf("Used Memory      : %ld MB\n",
           (mem_total - mem_available) / 1024);
}
