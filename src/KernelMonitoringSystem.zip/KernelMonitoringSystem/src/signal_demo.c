#include <stdio.h>
#include <signal.h>
#include <unistd.h>

#include "../include/signal_demo.h"

static volatile sig_atomic_t signal_received = 0;

static void handle_signal(int sig)
{
    if (sig == SIGINT)
    {
        signal_received = 1;
    }
}

void signal_demo()
{
    int seconds = 0;

    signal_received = 0;

    printf("\n===============================================\n");
    printf("              SIGNAL HANDLING\n");
    printf("===============================================\n");

    printf("Installing SIGINT handler...\n");

    if (signal(SIGINT, handle_signal) == SIG_ERR)
    {
        perror("signal");
        return;
    }

    printf("SIGINT handler installed successfully.\n");
    printf("\nPress Ctrl+C to send SIGINT.\n\n");

    while (!signal_received)
    {
        printf("Monitoring... %d seconds elapsed\n", seconds);

        fflush(stdout);

        sleep(1);
        seconds++;
    }

    signal(SIGINT, SIG_DFL);

    printf("\n-----------------------------------------------\n");
    printf("SIGINT signal received successfully.\n");
    printf("Signal handled without terminating the program.\n");
    printf("Returning to the main menu...\n");
    printf("-----------------------------------------------\n");
}
