#include <stdio.h>

#include "../include/process_monitor.h"
#include "../include/proc_monitor.h"
#include "../include/resource_monitor.h"
#include "../include/event_monitor.h"
#include "../include/signal_demo.h"
#include "../include/system_call_demo.h"

static void clear_input_buffer()
{
    int ch;

    while ((ch = getchar()) != '\n' && ch != EOF)
    {
    }
}

static void pause_screen()
{
    printf("\nPress Enter to continue...");
    getchar();
}

int main()
{
    int choice;

    while (1)
    {
        printf("\n");
        printf("===============================================\n");
        printf("       LINUX KERNEL MONITORING SYSTEM\n");
        printf("===============================================\n");
        printf("1. Process Monitoring\n");
        printf("2. Process Details (/proc)\n");
        printf("3. CPU Monitoring\n");
        printf("4. Memory Monitoring\n");
        printf("5. Process Creation & Termination\n");
        printf("6. Event Logging\n");
        printf("7. Signal Handling\n");
        printf("8. System Call Demo\n");
        printf("9. Full Monitoring\n");
        printf("0. Exit\n");
        printf("===============================================\n");
        printf("Enter your choice: ");

        if (scanf("%d", &choice) != 1)
        {
            clear_input_buffer();
            printf("\nInvalid input. Please enter a number.\n");
            continue;
        }

        clear_input_buffer();

        switch (choice)
        {
            case 1:
                process_monitor();
                pause_screen();
                break;

            case 2:
                proc_monitor();
                pause_screen();
                break;

            case 3:
                cpu_monitor();
                pause_screen();
                break;

            case 4:
                memory_monitor();
                pause_screen();
                break;

            case 5:
                process_event_monitor();
                break;

            case 6:
                event_monitor();
                break;

            case 7:
                signal_demo();
                break;

            case 8:
                system_call_demo();
                pause_screen();
                break;

            case 9:
                full_monitor();
                break;

            case 0:
                printf("\n===============================================\n");
                printf("Exiting Kernel Monitoring System...\n");
                printf("===============================================\n");
                return 0;

            default:
                printf("\nInvalid choice. Please try again.\n");
                pause_screen();
        }
    }

    return 0;
}
