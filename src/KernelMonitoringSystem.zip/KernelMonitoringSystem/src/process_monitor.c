#include <stdio.h>
#include <dirent.h>
#include <ctype.h>
#include <unistd.h>
#include <signal.h>

#include "../include/process_monitor.h"

static volatile sig_atomic_t stop_full_monitor = 0;

static void full_monitor_signal_handler(int sig)
{
    if (sig == SIGINT)
        stop_full_monitor = 1;
}

static int display_process_table()
{
    DIR *dir;
    struct dirent *entry;
    int count = 0;

    dir = opendir("/proc");

    if (dir == NULL)
    {
        perror("opendir");
        return 0;
    }

    printf("========== PROCESS MONITORING ==========\n\n");

    printf("%-8s %-8s %-8s %-25s\n",
           "PID", "PPID", "STATE", "NAME");

    printf("------------------------------------------------------\n");

    while ((entry = readdir(dir)) != NULL)
    {
        if (isdigit((unsigned char)entry->d_name[0]))
        {
            char path[512];
            char name[256];
            char state;
            int pid;
            int ppid;

            snprintf(path, sizeof(path),
                     "/proc/%s/stat", entry->d_name);

            FILE *fp = fopen(path, "r");

            if (fp != NULL)
            {
                if (fscanf(fp, "%d (%255[^)]) %c %d",
                           &pid, name, &state, &ppid) == 4)
                {
                    printf("%-8d %-8d %-8c %-25s\n",
                           pid, ppid, state, name);

                    count++;
                }

                fclose(fp);
            }
        }
    }

    closedir(dir);

    printf("------------------------------------------------------\n");
    printf("Total Processes: %d\n", count);

    return count;
}

void process_monitor()
{
    display_process_table();
}

void full_monitor()
{
    stop_full_monitor = 0;

    signal(SIGINT, full_monitor_signal_handler);

    printf("\n===============================================\n");
    printf("              FULL MONITORING\n");
    printf("===============================================\n");
    printf("Refreshing every 2 seconds...\n");
    printf("Press Ctrl+C to return to the main menu.\n");

    sleep(2);

    while (!stop_full_monitor)
    {
        printf("\033[2J\033[H");
        fflush(stdout);

        printf("===============================================\n");
        printf("       LINUX KERNEL MONITORING SYSTEM\n");
        printf("===============================================\n\n");

        display_process_table();

        printf("\n========== CPU MONITORING ==========\n");

        FILE *fp = fopen("/proc/loadavg", "r");

        if (fp != NULL)
        {
            double load1, load5, load15;
            int running, total;

            if (fscanf(fp, "%lf %lf %lf %d/%d",
                       &load1, &load5, &load15,
                       &running, &total) == 5)
            {
                printf("Load Average (1 min)  : %.2f\n", load1);
                printf("Load Average (5 min)  : %.2f\n", load5);
                printf("Load Average (15 min) : %.2f\n", load15);
                printf("Running Processes     : %d\n", running);
                printf("Total Processes       : %d\n", total);
            }

            fclose(fp);
        }

        printf("\n========== MEMORY MONITORING ==========\n");

        fp = fopen("/proc/meminfo", "r");

        if (fp != NULL)
        {
            char line[256];
            long mem_total = 0;
            long mem_available = 0;

            while (fgets(line, sizeof(line), fp))
            {
                if (sscanf(line, "MemTotal: %ld kB",
                           &mem_total) == 1)
                    continue;

                if (sscanf(line, "MemAvailable: %ld kB",
                           &mem_available) == 1)
                    continue;
            }

            fclose(fp);

            printf("Total Memory     : %ld MB\n",
                   mem_total / 1024);

            printf("Available Memory : %ld MB\n",
                   mem_available / 1024);

            printf("Used Memory      : %ld MB\n",
                   (mem_total - mem_available) / 1024);
        }

        printf("\n===============================================\n");
        printf("Refreshing in 2 seconds... Press Ctrl+C to stop.\n");

        sleep(2);
    }

    signal(SIGINT, SIG_DFL);

    printf("\nFull monitoring stopped.\n");
    printf("Returning to main menu...\n");
}
