#include <stdio.h>
#include <string.h>
#include "../include/proc_monitor.h"

void proc_monitor()
{
    char path[100];
    char buffer[256];
    int pid;

    printf("\n========== /PROC PROCESS DETAILS ==========\n");
    printf("Enter PID: ");
    scanf("%d", &pid);

    snprintf(path, sizeof(path), "/proc/%d/status", pid);

    FILE *fp = fopen(path, "r");

    if (fp == NULL)
    {
        printf("Process with PID %d not found.\n", pid);
        return;
    }

    while (fgets(buffer, sizeof(buffer), fp) != NULL)
    {
        if (strncmp(buffer, "Name:", 5) == 0 ||
            strncmp(buffer, "State:", 6) == 0 ||
            strncmp(buffer, "Pid:", 4) == 0 ||
            strncmp(buffer, "PPid:", 5) == 0 ||
            strncmp(buffer, "VmSize:", 7) == 0 ||
            strncmp(buffer, "VmRSS:", 6) == 0)
        {
            printf("%s", buffer);
        }
    }

    fclose(fp);
}
