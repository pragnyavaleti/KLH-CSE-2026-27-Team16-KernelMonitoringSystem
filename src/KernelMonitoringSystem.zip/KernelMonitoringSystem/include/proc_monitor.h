#ifndef PROC_MONITOR_H
#define PROC_MONITOR_H

void proc_monitor();

#endif
