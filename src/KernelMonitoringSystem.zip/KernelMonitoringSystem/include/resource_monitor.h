#ifndef RESOURCE_MONITOR_H
#define RESOURCE_MONITOR_H

void cpu_monitor();
void memory_monitor();

#endif
