#ifndef EVENT_MONITOR_H
#define EVENT_MONITOR_H

void process_event_monitor();
void event_monitor();

#endif
