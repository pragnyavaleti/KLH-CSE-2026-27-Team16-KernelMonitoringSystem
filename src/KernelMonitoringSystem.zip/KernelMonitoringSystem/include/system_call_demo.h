#ifndef SYSTEM_CALL_DEMO_H
#define SYSTEM_CALL_DEMO_H

void system_call_demo();

#endif
