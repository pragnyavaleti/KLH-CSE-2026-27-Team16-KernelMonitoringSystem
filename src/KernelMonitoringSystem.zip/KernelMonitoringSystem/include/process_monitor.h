#ifndef PROCESS_MONITOR_H
#define PROCESS_MONITOR_H

void process_monitor();
void full_monitor();

#endif
